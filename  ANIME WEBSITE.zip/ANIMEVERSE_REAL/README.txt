ANIMEVERSE REAL DATA WEBSITE

Built from: Anime_clean (1).csv
Records used: 19930
Open index.html in a modern browser.

No Python/Streamlit/Node is required to run this browser version.
The page contains the processed real dataset and client-side recommendation logic.
